#Importing Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#Loading Dataset
dataset = pd.read_csv("Data.csv")
#Dividing dataset into independent and dependent variables
X=dataset.iloc[:,:-1]
y=dataset.iloc[:,-1]
#Filling missing values by mean
from sklearn.preprocessing import Imputer
imputer = Imputer(missing_values = "NaN", strategy = "mean", axis = 0)
imputer= imputer.fit(X.iloc[:,1:3])
X.iloc[:,1:3] = imputer.transform(X.iloc[:,1:3])
#quantifying the categorical features
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoderX = LabelEncoder()
X.iloc[:,0]=labelencoderX.fit_transform(X.iloc[:,0])
#Encoding Labels into O's and 1's
onehotencoder = OneHotEncoder(categorical_features = [0])
X = onehotencoder.fit_transform(X).toarray()
#Removing first encoded column to avoid fearure trap
X = X[:,1:]
#Splitting the dataset into Training and Test datasets
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state=0)
#Scaling the splitted dataset 
from sklearn.preprocessing import StandardScaler
scaler_X = StandardScaler()
X_train = scaler_X.fit_transform(X_train)
X_test = scaler_X.transform(X_test)
